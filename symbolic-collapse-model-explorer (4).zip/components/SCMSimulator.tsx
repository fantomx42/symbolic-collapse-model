
import React from 'react';
import { SCMParameters, SCMCalculatedValues, TrendDirection, SymbolicNode } from '../types';
import { VARIABLE_DETAILS } from '../constants';
import { TrendArrow } from './TrendArrow';
import { Sparkline } from './Sparkline';

interface SCMSimulatorProps {
  symbolNode: SymbolicNode; // The currently selected symbol
  calculatedValues: SCMCalculatedValues;
  isPlaying: boolean;
  setIsPlaying: () => void; // Uses store's togglePlayPause
  simulationSpeedFactor: number;
  setSimulationSpeedFactor: (speed: number) => void; // Uses store's setSimulationSpeedFactor
  onTimeChange: (newTime: number) => void; // Callback for manual time changes (handled in App.tsx)
  updateParam: (key: keyof SCMParameters, value: number) => void; // Uses store's updateSelectedSymbolParam
}

const getTrend = (current?: number, previous?: number, epsilon = 0.001): TrendDirection => {
  if (current === undefined || previous === undefined || previous === null) return TrendDirection.NONE;
  if (Math.abs(current - previous) < epsilon) return TrendDirection.STABLE;
  if (current > previous) return TrendDirection.UP;
  return TrendDirection.DOWN;
};

const PlayIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg viewBox="0 0 20 20" fill="currentColor" className="w-5 h-5" {...props}>
    <path fillRule="evenodd" d="M2 10a8 8 0 1 1 16 0 8 8 0 0 1-16 0Zm6.39-2.908a.75.75 0 0 1 .932.091l3.5 2.75a.75.75 0 0 1 0 1.134l-3.5 2.75a.75.75 0 0 1-1.023-.932L9.523 10l-1.133-1.876a.75.75 0 0 1 .001-1.032Z" clipRule="evenodd" />
  </svg>
);

const PauseIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg viewBox="0 0 20 20" fill="currentColor" className="w-5 h-5" {...props}>
    <path fillRule="evenodd" d="M2 10a8 8 0 1 1 16 0 8 8 0 0 1-16 0Zm5-2.25A.75.75 0 0 1 7.75 7h.5a.75.75 0 0 1 .75.75v4.5a.75.75 0 0 1-.75.75h-.5a.75.75 0 0 1-.75-.75v-4.5Zm4 0a.75.75 0 0 1 .75-.75h.5a.75.75 0 0 1 .75.75v4.5a.75.75 0 0 1-.75.75h-.5a.75.75 0 0 1-.75-.75v-4.5Z" clipRule="evenodd" />
  </svg>
);

export const SCMSimulator: React.FC<SCMSimulatorProps> = ({ 
  symbolNode,
  calculatedValues,
  isPlaying,
  setIsPlaying, // This is togglePlayPause from store
  simulationSpeedFactor,
  setSimulationSpeedFactor, // This is setSimulationSpeedFactor from store
  onTimeChange,
  updateParam // This is updateSelectedSymbolParam from store
}) => {
  
  const { params, history: scmParamsHistory, previousParams, previousCalculatedValues } = symbolNode;

  const handleParamChange = (key: keyof SCMParameters, value: number) => {
    if (key === 'time') {
      onTimeChange(value); 
    } else {
      updateParam(key, value);
    }
  };

  const coreParamKeys: Array<keyof SCMParameters> = ['I', 'S', 'P', 'T', 'E'];
  const advancedParamKeys: Array<keyof SCMParameters> = ['lambda', 'R_memory', 'R_redundancy', 'R_anchoring'];

  const renderCalculatedValue = (label: string, currentValue: number, previousValue?: number | null) => (
    <div className="bg-gray-700 p-3 rounded-lg">
      <span className="block text-xs text-gray-400">{label}</span>
      <div className="flex items-center">
        <span className="text-xl font-bold text-indigo-300">{currentValue.toFixed(3)}</span>
        <TrendArrow direction={getTrend(currentValue, previousValue === null ? undefined : previousValue)} />
      </div>
    </div>
  );
  
  const renderParamSliderWithExtras = (key: keyof SCMParameters, disabled: boolean = false) => {
    const detail = VARIABLE_DETAILS[key];
    const historyData = scmParamsHistory ? scmParamsHistory[key] : [];
    return (
      <div key={key} className={`py-1 ${disabled ? 'opacity-70' : ''}`}>
        <div className="flex items-center justify-between mb-1">
            <label htmlFor={`${symbolNode.id}-${key}`} className="block text-sm font-medium text-purple-300">
                {detail.label}: <span className="text-indigo-300 font-bold">{params[key].toFixed(detail.step && detail.step < 1 ? 1 : 0)} {detail.unit || ''}</span>
            </label>
            <div className="flex items-center">
                <TrendArrow direction={getTrend(params[key], previousParams?.[key])} />
                <Sparkline 
                    data={historyData || []} 
                    width={50} 
                    height={16} 
                    color="#a5b4fc" 
                    minDomain={detail.min} 
                    maxDomain={detail.max}
                />
            </div>
        </div>
        {detail.description && <p className="text-xs text-gray-400 mb-1">{detail.description}</p>}
        <input
            type="range"
            id={`${symbolNode.id}-${key}`} // Unique ID using symbol ID
            name={key}
            min={detail.min}
            max={detail.max}
            step={detail.step}
            value={params[key]}
            onChange={(e) => handleParamChange(key, parseFloat(e.target.value))}
            className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer accent-indigo-500 hover:accent-indigo-400 transition-colors"
            disabled={disabled}
        />
      </div>
    );
  };

  const speedOptions = [
    { label: '0.25x', value: 0.25 },
    { label: '0.5x', value: 0.5 },
    { label: '1x', value: 1 },
    { label: '2x', value: 2 },
    { label: '5x', value: 5 },
  ];

  return (
    <div>
      <h3 className="text-xl font-semibold text-purple-300 mb-4">Adjust SCM Parameters for "{symbolNode.name}"</h3>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-1">
        {coreParamKeys.map(key => renderParamSliderWithExtras(key))}
      </div>

      <details className="mt-4 group" role="group" aria-label="Advanced SCM dynamics parameters">
        <summary className="text-lg font-semibold text-purple-300 hover:text-purple-200 cursor-pointer list-none flex items-center py-2">
          Advanced Dynamics & Resilience
          <span className="ml-2 transform transition-transform duration-200 group-open:rotate-90">&#9656;</span>
        </summary>
        <div className="mt-2 grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-1 p-4 bg-gray-700 bg-opacity-30 rounded-md">
          {advancedParamKeys.map(key => renderParamSliderWithExtras(key))}
        </div>
      </details>

      <div className="mt-6 pt-4 border-t border-gray-700">
        <h3 className="text-lg font-semibold text-purple-300 mb-3">Time & Entropy Controls</h3>
        <p className="text-xs text-gray-400 mb-3">
          As time advances for "{symbolNode.name}", symbolic entropy may degrade its T, E, and Resilience factors.
          The rate of decay is influenced by its I, S, P, and overall Resilience.
        </p>
        {renderParamSliderWithExtras('time', isPlaying)}
        <div className="flex items-center space-x-3 mt-3">
          <button
            onClick={setIsPlaying} // Calls togglePlayPause from store
            className={`p-2 rounded-full transition-colors flex items-center justify-center
                        ${isPlaying ? 'bg-red-500 hover:bg-red-400' : 'bg-green-500 hover:bg-green-400'} text-white`}
            aria-label={isPlaying ? "Pause simulation" : "Play simulation"}
          >
            {isPlaying ? <PauseIcon /> : <PlayIcon />}
          </button>
          <div>
            <label htmlFor="speed-select" className="text-xs text-gray-400 mr-2">Speed:</label>
            <select
              id="speed-select"
              value={simulationSpeedFactor}
              onChange={(e) => setSimulationSpeedFactor(parseFloat(e.target.value))}
              className="bg-gray-600 text-gray-200 border border-gray-500 rounded-md p-1.5 text-xs focus:ring-indigo-500 focus:border-indigo-500"
              aria-label="Simulation speed"
            >
              {speedOptions.map(opt => (
                <option key={opt.value} value={opt.value}>{opt.label}</option>
              ))}
            </select>
            <span className="text-xs text-gray-400 ml-2">({simulationSpeedFactor} tick{simulationSpeedFactor === 1 ? '' : 's'}/sec)</span>
          </div>
        </div>
      </div>

      <div className="mt-6 pt-4 border-t border-gray-700">
        <h3 className="text-lg font-semibold text-purple-300 mb-2">Calculated SCM Values for "{symbolNode.name}"</h3>
        <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-sm">
          {renderCalculatedValue("Raw Collapse (cRaw)", calculatedValues.cRaw, previousCalculatedValues?.cRaw)}
          {renderCalculatedValue("Time-Dependent C(t)", calculatedValues.C_t, previousCalculatedValues?.C_t)}
          {renderCalculatedValue("Resilience Factor (R)", calculatedValues.R, previousCalculatedValues?.R)}
          {renderCalculatedValue("Effective C (cEff)", calculatedValues.cEffective, previousCalculatedValues?.cEffective)}
        </div>
      </div>
    </div>
  );
};
