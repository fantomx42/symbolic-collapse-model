
import React from 'react';
import { SCM_VARIABLE_CONFIGS, FormulaDisplay, COLLAPSE_ZONES } from './constants';
import { useSCM } from './hooks/useSCM';
import SCMInputPanel from './components/SCMInputPanel';
import SCMOutputDisplay from './components/SCMOutputDisplay';
import NeuralNetVisualizer from './components/NeuralNetVisualizer';
import InfoSection from './components/InfoSection';
import InterventionGuide from './components/InterventionGuide';

const App: React.FC = () => {
  const { variables, SCMOutput, handleVariableChange, resetVariables } = useSCM();

  return (
    <div className="min-h-screen bg-gray-900 text-gray-100 p-4 md:p-8 selection:bg-cyan-500 selection:text-cyan-900">
      <header className="text-center mb-10">
        <h1 className="text-4xl md:text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-sky-400 to-indigo-500 mb-2 font-orbitron">
          Symbolic Collapse Model
        </h1>
        <p className="text-lg text-gray-400">
          An Interactive Neural Simulator for Meaning Breakdown
        </p>
      </header>

      <main className="max-w-7xl mx-auto space-y-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-start">
          <div className="lg:col-span-2 space-y-8">
            <InfoSection title="The Symbolic Collapse Equation">
              <p>
                The Symbolic Collapse Model (SCM) is a diagnostic tool designed to detect when symbolic systems—language, knowledge, institutions, cognition, or AI—begin to fail. At its core is this equation:
              </p>
              <FormulaDisplay />
              <p>
                The higher the value of <strong className="text-cyan-400">C</strong>, the greater the pressure on a system’s symbolic integrity.
                Adjust the sliders for each variable (I, S, P, T, E) on a 1-10 scale to see the impact.
              </p>
            </InfoSection>
            
            <div className="bg-gray-800 p-6 rounded-lg shadow-lg">
                <div className="flex justify-between items-center mb-6">
                    <h2 className="text-2xl font-semibold text-cyan-400">System Variables</h2>
                    <button
                        onClick={resetVariables}
                        className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-medium rounded-md transition-colors focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 focus:ring-offset-gray-800"
                    >
                        Reset Variables
                    </button>
                </div>
                <SCMInputPanel variables={variables} onVariableChange={handleVariableChange} />
            </div>
          </div>

          <div className="lg:col-span-1 space-y-8 sticky top-8">
            <SCMOutputDisplay output={SCMOutput} />
            <NeuralNetVisualizer variables={variables} scmOutput={SCMOutput} />
          </div>
        </div>

        <InfoSection title="Understanding Collapse Zones">
          <div className="space-y-2">
            {COLLAPSE_ZONES.map(zone => (
              <p key={zone.level}>
                <strong className={zone.color}>{zone.level} (C: {zone.minC === -Infinity ? '<' : zone.minC.toString()}{zone.maxC === Infinity ? '+' : `–${zone.maxC}`}):</strong> {zone.description}
              </p>
            ))}
             <p><strong className="text-red-700">Error / Critical (T or E = 0):</strong> If Transmission Fidelity (T) or Epistemic Coherence (E) drops to zero, the formula results in division by zero. This represents a fundamental breakdown where C approaches infinity, indicating an inevitable collapse. The system can no longer meaningfully transmit information or maintain internal consistency.</p>
          </div>
        </InfoSection>

        <InterventionGuide variables={variables} scmOutput={SCMOutput} />

        <InfoSection title="Model Overview & Purpose">
          <p><strong>What happens when meaning breaks down?</strong> This project explores that question—across minds, machines, messages, and civilizations.</p>
          <p><strong>Why This Exists:</strong> We live in a world of symbolic stress. AI models hallucinate under meaning strain. Institutions fracture from loss of coherence. Social discourse splinters when symbols no longer mean the same thing. SCM provides a way to measure that pressure—before collapse becomes irreversible.</p>
          <p><strong>Origins:</strong> This model draws inspiration from Claude Shannon’s Information Theory (signal, noise, overload) and Kurt Gödel’s Incompleteness Theorem (systems can’t always resolve their own failure).</p>
        </InfoSection>

        <InfoSection title="Detailed Variable Rubrics & Interventions">
            {Object.values(SCM_VARIABLE_CONFIGS).map(config => (
                <div key={config.key} className="mb-6 pb-4 border-b border-gray-700 last:border-b-0 last:pb-0">
                    <h3 className={`text-xl font-semibold ${config.color.replace('bg-','text-')} mb-2`}>{config.name}</h3>
                    <p className="text-sm text-gray-400 mb-2">{config.description}</p>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm mb-3">
                        <div>
                            <h4 className="font-medium text-gray-200 mb-1">Scoring Rubric:</h4>
                            <ul className="list-disc list-inside space-y-1 pl-1">
                                {config.rubric.map(item => (
                                    <li key={item.scoreRange}><strong>{item.scoreRange}:</strong> {item.description}</li>
                                ))}
                            </ul>
                        </div>
                        <div>
                            <h4 className="font-medium text-gray-200 mb-1">Intervention Focus:</h4>
                            <p><strong>If Problematic, It Signals:</strong> {config.interventionSignal}</p>
                            <p><strong>Potential Fix:</strong> {config.interventionFix}</p>
                        </div>
                    </div>
                </div>
            ))}
        </InfoSection>
        
        <footer className="text-center py-8 mt-12 border-t border-gray-700">
          <p className="text-gray-500 text-sm">
            Symbolic Collapse Model Simulator. Inspired by the SCM concept.
          </p>
        </footer>
      </main>
    </div>
  );
};

export default App;
