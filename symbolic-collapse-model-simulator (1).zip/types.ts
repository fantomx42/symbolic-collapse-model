
export interface SCMVariables {
  I: number; // Information Load
  S: number; // Symbolic Abstraction
  P: number; // Polarization
  T: number; // Transmission Fidelity
  E: number; // Epistemic Coherence
}

export type SCMVariableKey = keyof SCMVariables;

export enum CollapseRiskLevel {
  Stable = "Stable",
  SymbolicStress = "Symbolic Stress",
  NarrativeFracture = "Narrative Fracture",
  CollapseZone = "Collapse Zone",
  Error = "Error" // For division by zero or invalid inputs
}

export interface RubricItem {
  scoreRange: string;
  description: string;
}

export interface VariableConfig {
  key: SCMVariableKey;
  name: string;
  description: string;
  rubric: RubricItem[];
  interventionSignal: string;
  interventionFix: string;
  color: string; // Base color for visualization
}

export interface SCMOutput {
  C: number;
  riskLevel: CollapseRiskLevel;
  riskColor: string;
}
