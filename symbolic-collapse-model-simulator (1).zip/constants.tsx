
import React from 'react';
import { VariableConfig, SCMVariableKey, CollapseRiskLevel } from './types';

export const SCM_VARIABLE_CONFIGS: Record<SCMVariableKey, VariableConfig> = {
  I: {
    key: 'I',
    name: "Information Load (I)",
    description: "The volume, complexity, and speed of information a system processes.",
    rubric: [
      { scoreRange: "1–2", description: "Very simple, low-volume signal" },
      { scoreRange: "3–4", description: "Light content, minimal detail" },
      { scoreRange: "5–6", description: "Moderate complexity" },
      { scoreRange: "7–8", description: "Dense, cross-domain, fast-moving" },
      { scoreRange: "9–10", description: "Overwhelming data, jargon, overload" },
    ],
    interventionSignal: "Overload, firehose of content",
    interventionFix: "Summarize, filter, chunk, slow input",
    color: "bg-purple-500",
  },
  S: {
    key: 'S',
    name: "Symbolic Abstraction (S)",
    description: "The degree to which symbols are detached from concrete referents.",
    rubric: [
      { scoreRange: "1–2", description: "Literal, sensory, grounded" },
      { scoreRange: "3–4", description: "Slight generalization" },
      { scoreRange: "5–6", description: "Balanced abstract + concrete" },
      { scoreRange: "7–8", description: "Heavy use of theory/metaphor" },
      { scoreRange: "9–10", description: "Recursive, ungrounded, ideology-laden" },
    ],
    interventionSignal: "Detached, vague, ideology-saturated",
    interventionFix: "Reground in real examples, reduce metaphor, clarify terms",
    color: "bg-pink-500",
  },
  P: {
    key: 'P',
    name: "Polarization (P)",
    description: "The extent to which symbols evoke divisive or conflicting interpretations.",
    rubric: [
      { scoreRange: "1–2", description: "Broad consensus, neutral" },
      { scoreRange: "3–4", description: "Slight bias" },
      { scoreRange: "5–6", description: "Depends on audience worldview" },
      { scoreRange: "7–8", description: "Ideologically divisive" },
      { scoreRange: "9–10", description: "Highly antagonistic, symbolic warfare" },
    ],
    interventionSignal: "Interpretive fracture",
    interventionFix: "Neutral framing, viewpoint diversity, empathy modeling",
    color: "bg-red-500",
  },
  T: {
    key: 'T',
    name: "Transmission Fidelity (T)",
    description: "The clarity, precision, and robustness of symbolic communication.",
    rubric: [
      { scoreRange: "1–2", description: "Garbled, ambiguous, easily misread" },
      { scoreRange: "3–4", description: "Unclear or confusing" },
      { scoreRange: "5–6", description: "Interpretable with effort" },
      { scoreRange: "7–8", description: "Clear and well-structured" },
      { scoreRange: "9–10", description: "Extremely precise, resilient, repeatable meaning" },
    ],
    interventionSignal: "Ambiguity, miscommunication",
    interventionFix: "Repeat, simplify, define terms, structure clearly",
    color: "bg-blue-500",
  },
  E: {
    key: 'E',
    name: "Epistemic Coherence (E)",
    description: "The logical consistency, factual grounding, and internal integrity of a knowledge system.",
    rubric: [
      { scoreRange: "1–2", description: "Contradictory, incoherent, false" },
      { scoreRange: "3–4", description: "Spotty logic, cherry-picked data" },
      { scoreRange: "5–6", description: "Mostly coherent with gaps" },
      { scoreRange: "7–8", description: "Structured logic and internally consistent" },
      { scoreRange: "9–10", description: "Rigorous, falsifiable, deeply coherent knowledge system" },
    ],
    interventionSignal: "Contradiction, confusion",
    interventionFix: "Add sourcing, fact-checking, logical scaffolding",
    color: "bg-green-500",
  },
};

export const VARIABLE_KEYS: SCMVariableKey[] = ['I', 'S', 'P', 'T', 'E'];

export const INITIAL_VARIABLES: Record<SCMVariableKey, number> = {
  I: 5,
  S: 5,
  P: 5,
  T: 5,
  E: 5,
};

export const COLLAPSE_ZONES: Array<{
  minC: number;
  maxC: number;
  level: CollapseRiskLevel;
  color: string;
  description: string;
}> = [
  { minC: -Infinity, maxC: 3, level: CollapseRiskLevel.Stable, color: "text-green-400", description: "System is stable and resilient." },
  { minC: 3, maxC: 7, level: CollapseRiskLevel.SymbolicStress, color: "text-yellow-400", description: "System is under stress, potential for misinterpretations." },
  { minC: 7, maxC: 10, level: CollapseRiskLevel.NarrativeFracture, color: "text-orange-400", description: "Narratives are fracturing, coherence is significantly weakened." },
  { minC: 10, maxC: Infinity, level: CollapseRiskLevel.CollapseZone, color: "text-red-500", description: "System is in a collapse zone, high risk of breakdown." },
];

export const FormulaDisplay: React.FC = () => (
  <div className="my-4 p-4 bg-gray-800 rounded-lg shadow-inner text-center">
    <p className="text-2xl font-mono text-cyan-400 tracking-wider">
      <span className="text-gray-300">C = (</span>
      <span className="text-purple-400">I</span>
      <span className="text-gray-300"> * </span>
      <span className="text-pink-400">S</span>
      <span className="text-gray-300"> * </span>
      <span className="text-red-400">P</span>
      <span className="text-gray-300">) / (</span>
      <span className="text-blue-400">T</span>
      <span className="text-gray-300"> * </span>
      <span className="text-green-400">E</span>
      <span className="text-gray-300">)</span>
    </p>
  </div>
);
