
import { useState, useCallback, useMemo } from 'react';
import { SCMVariables, SCMVariableKey, CollapseRiskLevel, SCMOutput } from '../types';
import { INITIAL_VARIABLES, COLLAPSE_ZONES } from '../constants';

export const useSCM = (initialValues: SCMVariables = INITIAL_VARIABLES) => {
  const [variables, setVariables] = useState<SCMVariables>(initialValues);

  const handleVariableChange = useCallback((key: SCMVariableKey, value: number) => {
    setVariables(prev => ({ ...prev, [key]: value }));
  }, []);

  const SCMOutput = useMemo<SCMOutput>(() => {
    const { I, S, P, T, E } = variables;
    if (T === 0 || E === 0) {
      // Handle division by zero: Max out C or return specific error state
      const maxPossibleC = (10 * 10 * 10) / (1 * 1); // Theoretical max with T,E=1
      const cValue = T === 0 && E === 0 ? maxPossibleC * 2 : (T === 0 || E === 0 ? maxPossibleC : 0);
      return {
        C: cValue, // Or a very large number like Infinity
        // FIX: Use CollapseRiskLevel.Error for division by zero case
        riskLevel: CollapseRiskLevel.Error, 
        riskColor: "text-red-700 bg-red-900 border-red-700", // Distinct error color
      };
    }

    const C = (I * S * P) / (T * E);
    
    for (const zone of COLLAPSE_ZONES) {
      if (C >= zone.minC && C < zone.maxC) {
        return { C, riskLevel: zone.level, riskColor: zone.color };
      }
    }
    // Fallback, should be covered by COLLAPSE_ZONES ranges
    return { C, riskLevel: CollapseRiskLevel.Error, riskColor: "text-gray-500" };

  }, [variables]);

  const resetVariables = useCallback(() => {
    setVariables(INITIAL_VARIABLES);
  }, []);

  return {
    variables,
    SCMOutput,
    handleVariableChange,
    resetVariables,
  };
};