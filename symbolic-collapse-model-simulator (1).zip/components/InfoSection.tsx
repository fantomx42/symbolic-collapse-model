
import React, { PropsWithChildren } from 'react';

interface InfoSectionProps {
  title: string;
}

const InfoSection: React.FC<PropsWithChildren<InfoSectionProps>> = ({ title, children }) => {
  return (
    <div className="bg-gray-800 p-6 rounded-lg shadow-lg mb-6">
      <h2 className="text-2xl font-semibold text-cyan-400 mb-4 border-b-2 border-gray-700 pb-2">{title}</h2>
      <div className="space-y-3 text-gray-300 leading-relaxed">
        {children}
      </div>
    </div>
  );
};

export default InfoSection;
