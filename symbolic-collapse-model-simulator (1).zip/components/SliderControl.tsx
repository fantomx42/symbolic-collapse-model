
import React from 'react';

interface SliderControlProps {
  id: string;
  label: string;
  value: number;
  min?: number;
  max?: number;
  step?: number;
  onChange: (value: number) => void;
  colorClass?: string; // e.g., accent-blue-500
}

const SliderControl: React.FC<SliderControlProps> = ({
  id,
  label,
  value,
  min = 1,
  max = 10,
  step = 1,
  onChange,
  colorClass = "accent-cyan-500"
}) => {
  return (
    <div className="mb-4">
      <label htmlFor={id} className="block text-sm font-medium text-gray-300 mb-1">
        {label}: <span className={`font-bold text-lg ${colorClass ? colorClass.replace('accent-', 'text-') : 'text-cyan-400'}`}>{value}</span>
      </label>
      <input
        type="range"
        id={id}
        name={id}
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(parseFloat(e.target.value))}
        className={`w-full h-3 bg-gray-700 rounded-lg appearance-none cursor-pointer ${colorClass} transition-all duration-150 ease-in-out focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800 ${colorClass ? colorClass.replace('accent-', 'focus:ring-') : 'focus:ring-cyan-500'}`}
      />
    </div>
  );
};

export default SliderControl;
