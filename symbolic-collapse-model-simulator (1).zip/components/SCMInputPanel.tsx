
import React from 'react';
import { SCMVariables, SCMVariableKey } from '../types';
import { SCM_VARIABLE_CONFIGS, VARIABLE_KEYS } from '../constants';
import VariableCard from './VariableCard';

interface SCMInputPanelProps {
  variables: SCMVariables;
  onVariableChange: (key: SCMVariableKey, value: number) => void;
}

const SCMInputPanel: React.FC<SCMInputPanelProps> = ({ variables, onVariableChange }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {VARIABLE_KEYS.map(key => (
        <VariableCard
          key={key}
          config={SCM_VARIABLE_CONFIGS[key]}
          value={variables[key]}
          onValueChange={onVariableChange}
        />
      ))}
    </div>
  );
};

export default SCMInputPanel;
