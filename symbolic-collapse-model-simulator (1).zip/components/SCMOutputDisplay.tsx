
import React from 'react';
// FIX: Import CollapseRiskLevel
import { SCMOutput, CollapseRiskLevel } from '../types';
import { COLLAPSE_ZONES } from '../constants';

interface SCMOutputDisplayProps {
  output: SCMOutput;
}

const SCMOutputDisplay: React.FC<SCMOutputDisplayProps> = ({ output }) => {
  const currentZone = COLLAPSE_ZONES.find(zone => zone.level === output.riskLevel);
  
  return (
    <div className={`p-6 rounded-lg shadow-xl text-center bg-gray-800 border-t-4 ${currentZone && output.riskLevel !== CollapseRiskLevel.Error ? currentZone.color.replace('text-', 'border-') : output.riskLevel === CollapseRiskLevel.Error ? 'border-red-700' : 'border-gray-700'}`}>
      <h3 className="text-sm font-medium text-gray-400 uppercase tracking-wider mb-1">Collapse Pressure Score</h3>
      <p className="text-6xl font-bold font-orbitron" style={{ color: currentZone && output.riskLevel !== CollapseRiskLevel.Error ? currentZone.color.replace('text-', '#') : output.riskLevel === CollapseRiskLevel.Error ? '#EF4444' : '#F3F4F6' }}>
        {output.C.toFixed(2)}
      </p>
      <p className={`mt-2 text-2xl font-semibold ${currentZone && output.riskLevel !== CollapseRiskLevel.Error ? currentZone.color : output.riskLevel === CollapseRiskLevel.Error ? 'text-red-400' : 'text-gray-300'}`}>
        {output.riskLevel}
      </p>
      {currentZone && output.riskLevel !== CollapseRiskLevel.Error && (
        <p className="mt-1 text-sm text-gray-400">{currentZone.description}</p>
      )}
       {/* FIX: Check output.riskLevel for CollapseRiskLevel.Error, remove T/E check */}
       {output.riskLevel === CollapseRiskLevel.Error && (
         <p className="mt-1 text-sm text-red-400">Error: Division by zero (T or E is 0). Collapse inevitable.</p>
       )}
    </div>
  );
};

export default SCMOutputDisplay;