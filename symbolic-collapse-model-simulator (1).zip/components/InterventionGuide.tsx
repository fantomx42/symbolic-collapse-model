
import React from 'react';
// FIX: Import CollapseRiskLevel
import { SCMVariables, SCMOutput, CollapseRiskLevel } from '../types';
import { SCM_VARIABLE_CONFIGS, VARIABLE_KEYS } from '../constants';

interface InterventionGuideProps {
  variables: SCMVariables;
  scmOutput: SCMOutput;
}

const InterventionGuide: React.FC<InterventionGuideProps> = ({ variables, scmOutput }) => {
  // FIX: Compare with enum member CollapseRiskLevel.Stable
  if (scmOutput.riskLevel === CollapseRiskLevel.Stable) {
    return (
      <div className="bg-gray-800 p-6 rounded-lg shadow-lg text-center">
        <h3 className="text-xl font-semibold text-green-400 mb-2">System Stable</h3>
        <p className="text-gray-300">The symbolic system appears to be resilient. Continue monitoring best practices.</p>
      </div>
    );
  }

  const problematicVariables = VARIABLE_KEYS.filter(key => {
    const value = variables[key];
    if (key === 'I' || key === 'S' || key === 'P') return value >= 7; // High is bad
    if (key === 'T' || key === 'E') return value <= 3; // Low is bad
    return false;
  });

  return (
    <div className="bg-gray-800 p-6 rounded-lg shadow-lg">
      <h3 className="text-xl font-semibold text-orange-400 mb-4">Intervention Guide</h3>
      {/* FIX: Compare with enum member CollapseRiskLevel.Stable */}
      {problematicVariables.length === 0 && scmOutput.riskLevel !== CollapseRiskLevel.Stable && scmOutput.riskLevel !== CollapseRiskLevel.Error && (
        <p className="text-gray-300">The system is under stress, but no single variable is critically high/low. Consider a holistic review or minor adjustments across multiple factors.</p>
      )}
      {problematicVariables.map(key => {
        const config = SCM_VARIABLE_CONFIGS[key];
        const textColor = config.color.replace('bg-', 'text-');
        return (
          <div key={key} className="mb-4 pb-4 border-b border-gray-700 last:border-b-0 last:pb-0">
            <h4 className={`font-semibold ${textColor}`}>{config.name} is problematic (Score: {variables[key]})</h4>
            <p className="text-sm text-gray-400 mt-1">
              <strong>Signals:</strong> {config.interventionSignal}
            </p>
            <p className="text-sm text-gray-300 mt-1">
              <strong>Recommended Action:</strong> {config.interventionFix}
            </p>
          </div>
        );
      })}
       {/* Display this message if riskLevel is Error (which implies T or E is 0 based on useSCM changes) */}
       { scmOutput.riskLevel === CollapseRiskLevel.Error && (
        <div className="mt-4 p-4 bg-red-900 border border-red-700 rounded-md">
          <h4 className="font-semibold text-red-300">Critical Alert: Denominator at Zero!</h4>
          <p className="text-sm text-red-400 mt-1">
            <strong>Signal:</strong> {variables.T === 0 ? SCM_VARIABLE_CONFIGS['T'].name : ''} {variables.T === 0 && variables.E === 0 ? 'and' : ''} {variables.E === 0 ? SCM_VARIABLE_CONFIGS['E'].name : ''} is at zero.
          </p>
          <p className="text-sm text-red-300 mt-1">
            <strong>Impact:</strong> This leads to an infinite or undefined collapse pressure score (C). The system is fundamentally broken in its ability to transmit meaning or maintain coherence.
          </p>
          <p className="text-sm text-red-300 mt-1">
            <strong>Recommended Action:</strong> Immediate and drastic intervention is required to restore {variables.T === 0 ? 'Transmission Fidelity (T)' : ''} {variables.T === 0 && variables.E === 0 ? 'and ' : ''} {variables.E === 0 ? 'Epistemic Coherence (E)' : ''}. Without this, symbolic collapse is guaranteed.
          </p>
        </div>
      )}
    </div>
  );
};

export default InterventionGuide;