
import React, { useState } from 'react';
import { SCMVariableKey, VariableConfig } from '../types';
import SliderControl from './SliderControl';

interface VariableCardProps {
  config: VariableConfig;
  value: number;
  onValueChange: (key: SCMVariableKey, value: number) => void;
}

const VariableCard: React.FC<VariableCardProps> = ({ config, value, onValueChange }) => {
  const [showRubric, setShowRubric] = useState(false);

  const accentColor = config.color.replace('bg-', 'accent-');
  const textColor = config.color.replace('bg-', 'text-');
  const borderColor = config.color.replace('bg-', 'border-');

  return (
    <div className={`bg-gray-800 p-4 rounded-lg shadow-lg border-l-4 ${borderColor}`}>
      <h3 className={`text-xl font-semibold mb-2 ${textColor}`}>{config.name}</h3>
      <p className="text-sm text-gray-400 mb-3">{config.description}</p>
      
      <SliderControl
        id={config.key}
        label="Score"
        value={value}
        onChange={(val) => onValueChange(config.key, val)}
        colorClass={accentColor}
      />

      <button 
        onClick={() => setShowRubric(!showRubric)}
        className={`mt-2 text-sm ${textColor} hover:underline focus:outline-none`}
      >
        {showRubric ? 'Hide' : 'Show'} Scoring Rubric
      </button>

      {showRubric && (
        <div className="mt-3 bg-gray-700 p-3 rounded text-xs text-gray-300 max-h-32 overflow-y-auto">
          <h4 className="font-semibold mb-1">Scoring Rubric (1-10):</h4>
          <ul>
            {config.rubric.map((item, index) => (
              <li key={index} className="mb-1">
                <strong className={textColor}>{item.scoreRange}:</strong> {item.description}
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};

export default VariableCard;
