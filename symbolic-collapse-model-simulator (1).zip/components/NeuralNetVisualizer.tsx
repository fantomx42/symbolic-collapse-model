
import React from 'react';
// FIX: Import CollapseRiskLevel
import { SCMVariables, SCMOutput, SCMVariableKey, CollapseRiskLevel } from '../types';
import { SCM_VARIABLE_CONFIGS } from '../constants';

interface NeuralNetVisualizerProps {
  variables: SCMVariables;
  scmOutput: SCMOutput;
}

const Node: React.FC<{ cx: number; cy: number; r: number; fill: string; label: string; value: number; textColor?: string; pulse?: boolean }> = 
  ({ cx, cy, r, fill, label, value, textColor = "#E5E7EB", pulse = false }) => (
  <g transform={`translate(${cx}, ${cy})`}>
    <circle 
      cx="0" 
      cy="0" 
      r={r} 
      fill={fill} 
      stroke="#9CA3AF" 
      strokeWidth="2"
    >
      {pulse && (
        <animate 
          attributeName="r" 
          values={`${r};${r * 1.1};${r}`} 
          dur="1.5s" 
          repeatCount="indefinite" 
        />
      )}
    </circle>
    <text x="0" y="-5" textAnchor="middle" fontSize="12" fill={textColor} fontWeight="bold">{label}</text>
    <text x="0" y="15" textAnchor="middle" fontSize="10" fill={textColor}>{value.toFixed(1)}</text>
  </g>
);

const Connection: React.FC<{ x1: number; y1: number; x2: number; y2: number; stroke: string; intensity: number }> = 
  ({ x1, y1, x2, y2, stroke, intensity }) => (
  <line 
    x1={x1} y1={y1} 
    x2={x2} y2={y2} 
    stroke={stroke} 
    strokeWidth={1 + intensity * 2} // Modulate width by intensity
    opacity={0.3 + intensity * 0.7} // Modulate opacity
  />
);


const NeuralNetVisualizer: React.FC<NeuralNetVisualizerProps> = ({ variables, scmOutput }) => {
  const baseRadius = 25;
  const centerRadius = 45;
  const width = 500;
  const height = 300;

  // Normalize C for animation intensity (0 to 1)
  // Max C could be high, let's cap visualization intensity at C=20 for example
  const cIntensity = Math.min(1, scmOutput.C / 20); 
  const pulseCentralNode = scmOutput.C > 7 && scmOutput.riskLevel !== CollapseRiskLevel.Error;


  const getNodeColor = (key: SCMVariableKey): string => {
    const config = SCM_VARIABLE_CONFIGS[key];
    const value = variables[key];
    let opacity = 0.3 + (value / 10) * 0.7; // Base opacity on value

    if ((key === 'T' || key === 'E') && value < 3) opacity = 0.3 + ((10 - value) / 10) * 0.7; // Higher opacity for low T/E (bad)
    else if (!(key === 'T' || key === 'E') && value > 7) opacity = 0.3 + (value / 10) * 0.7; // Higher opacity for high I,S,P (bad)


    const colorMap: Record<string, string> = {
      'bg-purple-500': `rgba(168, 85, 247, ${opacity})`, // I
      'bg-pink-500': `rgba(236, 72, 153, ${opacity})`,   // S
      'bg-red-500': `rgba(239, 68, 68, ${opacity})`,     // P
      'bg-blue-500': `rgba(59, 130, 246, ${opacity})`,   // T
      'bg-green-500': `rgba(34, 197, 94, ${opacity})`,  // E
    };
    return colorMap[config.color] || `rgba(107, 114, 128, ${opacity})`; // Default gray
  };
  
  const getCentralNodeColor = (): string => {
    // FIX: Use CollapseRiskLevel.Error and rely on it being set for T/E=0 cases
    if (scmOutput.riskLevel === CollapseRiskLevel.Error) return "rgba(127, 29, 29, 0.9)"; // Dark red for critical error
    if (scmOutput.riskLevel === CollapseRiskLevel.Stable) return `rgba(74, 222, 128, ${0.5 + cIntensity * 0.5})`; // Greenish
    if (scmOutput.riskLevel === CollapseRiskLevel.SymbolicStress) return `rgba(250, 204, 21, ${0.5 + cIntensity * 0.5})`; // Yellowish
    if (scmOutput.riskLevel === CollapseRiskLevel.NarrativeFracture) return `rgba(251, 146, 60, ${0.6 + cIntensity * 0.4})`; // Orangish
    if (scmOutput.riskLevel === CollapseRiskLevel.CollapseZone) return `rgba(239, 68, 68, ${0.7 + cIntensity * 0.3})`; // Reddish
    return `rgba(156, 163, 175, ${0.5 + cIntensity * 0.5})`; // Default
  };

  const nodePositions = {
    I: { x: width * 0.15, y: height * 0.2 },
    S: { x: width * 0.15, y: height * 0.5 },
    P: { x: width * 0.15, y: height * 0.8 },
    T: { x: width * 0.85, y: height * 0.3 },
    E: { x: width * 0.85, y: height * 0.7 },
    C: { x: width * 0.5, y: height * 0.5 },
  };

  // Calculate connection intensity (0 to 1) based on variable value
  const getConnectionIntensity = (key: SCMVariableKey) => {
    const value = variables[key];
    if (key === 'T' || key === 'E') {
      return (10 - value) / 9; // Higher intensity for lower T/E (bad)
    }
    return value / 10; // Higher intensity for higher I/S/P (bad)
  };

  return (
    <div className="bg-gray-800 p-4 rounded-lg shadow-xl flex justify-center items-center min-h-[350px]">
      <svg viewBox={`0 0 ${width} ${height}`} className="w-full max-w-lg">
        <defs>
          <filter id="glow">
            <feGaussianBlur stdDeviation="3.5" result="coloredBlur"/>
            <feMerge>
              <feMergeNode in="coloredBlur"/>
              <feMergeNode in="SourceGraphic"/>
            </feMerge>
          </filter>
        </defs>

        {/* Connections */}
        {(['I', 'S', 'P'] as SCMVariableKey[]).map(key => (
          <Connection 
            key={`conn-${key}`}
            x1={nodePositions[key].x} y1={nodePositions[key].y}
            x2={nodePositions.C.x} y2={nodePositions.C.y}
            stroke={getNodeColor(key)}
            intensity={getConnectionIntensity(key)}
          />
        ))}
        {(['T', 'E'] as SCMVariableKey[]).map(key => (
          <Connection 
            key={`conn-${key}`}
            x1={nodePositions[key].x} y1={nodePositions[key].y}
            x2={nodePositions.C.x} y2={nodePositions.C.y}
            stroke={getNodeColor(key)} // Using node color for connection to C
            intensity={getConnectionIntensity(key)}
          />
        ))}

        {/* Nodes */}
        {(['I', 'S', 'P', 'T', 'E'] as SCMVariableKey[]).map(key => (
          <Node 
            key={key}
            cx={nodePositions[key].x} cy={nodePositions[key].y}
            r={baseRadius + variables[key] * 0.5 - ((key === 'T' || key === 'E') ? variables[key]*0.8 : 0) } // T, E smaller when high (good)
            fill={getNodeColor(key)}
            label={key}
            value={variables[key]}
            pulse={ (key === 'I' || key === 'S' || key === 'P') && variables[key] > 7 || ( (key === 'T' || key === 'E') && variables[key] < 3 ) }
          />
        ))}
        
        {/* Central Node C */}
        <g transform={`translate(${nodePositions.C.x}, ${nodePositions.C.y})`} filter={pulseCentralNode ? "url(#glow)" : ""}>
           <circle 
            cx="0" 
            cy="0" 
            r={centerRadius + cIntensity * 10} 
            fill={getCentralNodeColor()} 
            stroke="#D1D5DB" 
            strokeWidth="3"
          >
            {pulseCentralNode && (
              <animate 
                attributeName="r" 
                values={`${centerRadius + cIntensity * 10};${centerRadius + cIntensity * 10 + 5};${centerRadius + cIntensity * 10}`} 
                dur={`${2 - cIntensity * 1.5}s`} // Faster pulse for higher intensity
                repeatCount="indefinite" 
              />
            )}
             {pulseCentralNode && (
                <animate 
                attributeName="opacity" 
                values="1;0.7;1"
                dur={`${2 - cIntensity * 1.5}s`}
                repeatCount="indefinite" 
              />
             )}
          </circle>
          <text x="0" y="-8" textAnchor="middle" fontSize="20" fill="#F9FAFB" fontWeight="bold">C</text>
          <text x="0" y="18" textAnchor="middle" fontSize="16" fill="#F9FAFB" fontWeight="bold">{scmOutput.C.toFixed(2)}</text>
        </g>
      </svg>
    </div>
  );
};

export default NeuralNetVisualizer;