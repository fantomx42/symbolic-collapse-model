
import React, { useState, useCallback, useEffect, useRef } from 'react';
import { SCMParameters, SCMCalculatedValues, CollapseZone, TrendDirection, SCMParameterHistory, SymbolicNode } from '../types';
import { DEFAULT_SCM_PARAMETERS, VARIABLE_DETAILS, COLLAPSE_ZONE_THRESHOLDS } from '../constants';
import { miniPredict } from '../utils/miniPredict';
import { extractSCMFromText } from '../utils/extractSCMFromText';
import { CollapseMeter } from './CollapseMeter';
import { TrendArrow } from './TrendArrow';
import { Sparkline } from './Sparkline';
import { SCMAnalysisInsights } from './SCMAnalysisInsights';
import { useSymbolStore } from '../store'; // Import Zustand store

interface SCMNNPlaygroundProps {
  computeSCM: (params: SCMParameters) => SCMCalculatedValues;
  selectedSymbol: SymbolicNode | undefined; // Pass the selected symbol
}

const MAX_HISTORY_POINTS_NN = 15; // This could be managed by the symbol's own history length

const getTrend = (current?: number, previous?: number | null, epsilon = 0.001): TrendDirection => {
  if (current === undefined || previous === undefined || previous === null) return TrendDirection.NONE;
  if (Math.abs(current - previous) < epsilon) return TrendDirection.STABLE;
  if (current > previous) return TrendDirection.UP;
  return TrendDirection.DOWN;
};

export const SCMNNPlayground: React.FC<SCMNNPlaygroundProps> = ({ computeSCM, selectedSymbol }) => {
  const { updateSelectedSymbolParams, addSymbol, selectSymbol: selectSymbolInStore } = useSymbolStore(state => ({
    updateSelectedSymbolParams: state.updateSelectedSymbolParams,
    addSymbol: state.addSymbol,
    selectSymbol: state.selectSymbol,
  }));

  const [inputText, setInputText] = useState<string>('');
  const [rawPrediction, setRawPrediction] = useState<string | null>(null);
  const [finalOutput, setFinalOutput] = useState<string | null>(null);
  
  // Editable params are now local to this component, derived from selectedSymbol
  const [editableScmParams, setEditableScmParams] = useState<SCMParameters | null>(null);
  const [currentScmResultForPlayground, setCurrentScmResultForPlayground] = useState<SCMCalculatedValues | null>(null);
  
  // Previous SCM params and results specific to the playground's internal re-evaluations
  const prevPlaygroundScmParamsRef = useRef<SCMParameters | null>(null);
  const prevPlaygroundScmResultRef = useRef<SCMCalculatedValues | null>(null);
  const [playgroundHistory, setPlaygroundHistory] = useState<SCMParameterHistory>(() => {
    const initialHistory: SCMParameterHistory = {} as SCMParameterHistory;
    (Object.keys(DEFAULT_SCM_PARAMETERS) as Array<keyof SCMParameters>).forEach(key => {
        initialHistory[key] = []; 
    });
    return initialHistory;
  });


  // Sync editableScmParams when selectedSymbol changes
  useEffect(() => {
    if (selectedSymbol) {
      setEditableScmParams(JSON.parse(JSON.stringify(selectedSymbol.params))); // Deep copy
      // Initial SCM result for playground based on selected symbol
      const initialResult = computeSCM(selectedSymbol.params);
      setCurrentScmResultForPlayground(initialResult);
      setPlaygroundHistory(selectedSymbol.history); // Or initialize fresh history for playground context
      setRawPrediction(null); // Clear old prediction when symbol changes
      setFinalOutput(null);
    } else {
      // If no symbol selected, start with default params for playground
      setEditableScmParams(JSON.parse(JSON.stringify(DEFAULT_SCM_PARAMETERS)));
      setCurrentScmResultForPlayground(computeSCM(DEFAULT_SCM_PARAMETERS));
      setPlaygroundHistory(createInitialHistory()); // Initialize empty history
      setRawPrediction(null);
      setFinalOutput(null);
    }
  }, [selectedSymbol, computeSCM]);

  const createInitialHistory = (): SCMParameterHistory => {
    const history: SCMParameterHistory = {} as SCMParameterHistory;
    (Object.keys(DEFAULT_SCM_PARAMETERS) as Array<keyof SCMParameters>).forEach(key => {
      history[key] = [];
    });
    return history;
  };


  const processAndSetPlaygroundResults = (paramsToProcess: SCMParameters, basePrediction: string | null) => {
    prevPlaygroundScmParamsRef.current = editableScmParams ? {...editableScmParams} : null;
    setEditableScmParams(JSON.parse(JSON.stringify(paramsToProcess))); // Update editable params

    const result = computeSCM(paramsToProcess);
    prevPlaygroundScmResultRef.current = currentScmResultForPlayground ? {...currentScmResultForPlayground} : null;
    setCurrentScmResultForPlayground(result);

    // Update playground-specific history
    setPlaygroundHistory(prevHistory => {
        const newHistory = { ...prevHistory } as SCMParameterHistory;
        (Object.keys(paramsToProcess) as Array<keyof SCMParameters>).forEach(key => {
            const currentValue = paramsToProcess[key];
            const historyForKey = prevHistory[key] ? [...prevHistory[key]] : [];
            historyForKey.push(currentValue);
            if (historyForKey.length > MAX_HISTORY_POINTS_NN) historyForKey.shift();
            newHistory[key] = historyForKey;
        });
        return newHistory;
    });

    if (result.zone === CollapseZone.Critical) { 
      setFinalOutput(`⚠️ Output suppressed due to high symbolic collapse risk (Effective Zone: ${COLLAPSE_ZONE_THRESHOLDS[result.zone].label}). Review derived SCM parameters.`);
    } else {
      setFinalOutput(basePrediction);
    }
  };

  const handleProcessText = useCallback(() => {
    const prediction = miniPredict(inputText);
    setRawPrediction(prediction);

    const derivedParams = extractSCMFromText(inputText, prediction);
    // These derived params become the new 'editableScmParams' for the playground
    processAndSetPlaygroundResults(derivedParams, prediction);
    // Optionally, offer to create a new symbol with these params or update selected one
  }, [inputText, computeSCM]);

  const handleReEvaluatePlayground = useCallback(() => {
    if (editableScmParams) {
      // Re-process with current editableScmParams for the playground
      processAndSetPlaygroundResults(editableScmParams, rawPrediction);
    }
  }, [editableScmParams, rawPrediction, computeSCM]);

  const handleApplyToSelectedSymbol = useCallback(() => {
    if (selectedSymbol && editableScmParams) {
      updateSelectedSymbolParams(editableScmParams);
      // After applying, the selectedSymbol in the store will update,
      // and the useEffect will sync editableScmParams again.
      alert(`Parameters from playground applied to symbol: "${selectedSymbol.name}"`);
    }
  }, [selectedSymbol, editableScmParams, updateSelectedSymbolParams]);
  
  const handleCreateSymbolFromPlayground = useCallback(() => {
    if (editableScmParams && rawPrediction) {
      const symbolName = `${rawPrediction} (from text: "${inputText.substring(0,20)}...")`;
      addSymbol(symbolName);
      // The new symbol is added, now find its ID to update its params
      // This is a bit indirect; ideally addSymbol could return the new symbol or ID
      // For now, assume it gets auto-selected or we select the last one.
      // This part needs robust handling of symbol ID after creation.
      // A quick timeout or a more direct way to get the new symbol's ID is needed.
      setTimeout(() => {
        const newSymbols = useSymbolStore.getState().symbols;
        const latestSymbol = newSymbols[newSymbols.length - 1];
        if (latestSymbol) {
          selectSymbolInStore(latestSymbol.id); // Select the new symbol
          // Now update its params after it has been created and selected
          useSymbolStore.getState().updateSelectedSymbolParams(editableScmParams);
           alert(`New symbol "${latestSymbol.name}" created and parameters applied.`);
        }
      }, 100);
    }
  },[editableScmParams, rawPrediction, inputText, addSymbol, selectSymbolInStore]);


  const handleEditableParamChange = (key: keyof SCMParameters, value: string) => {
    if (editableScmParams) {
      const numValue = parseFloat(value);
      if (!isNaN(numValue)) {
        const detail = VARIABLE_DETAILS[key];
        let constrainedValue = numValue;
        
        if ((key === 'T' || key === 'E') && detail.min !== undefined && constrainedValue < detail.min) constrainedValue = detail.min;
        else if (detail.min !== undefined) constrainedValue = Math.max(detail.min, constrainedValue);

        if (detail.max !== undefined) constrainedValue = Math.min(detail.max, constrainedValue);


        setEditableScmParams({ ...editableScmParams, [key]: constrainedValue });
      }
    }
  };
  
  const renderParamDisplayOrInput = (key: keyof SCMParameters) => {
    if (!editableScmParams) return null;
    const detail = VARIABLE_DETAILS[key];
    const value = editableScmParams[key] !== undefined ? editableScmParams[key] : detail.min ?? 0;
    // Trend for playground is based on its own internal state changes
    const prevValueForTrend = prevPlaygroundScmParamsRef.current?.[key];

    return (
      <div key={key} className="p-2 bg-gray-700 rounded-md flex flex-col justify-between">
        <div>
          <div className="flex items-center justify-between mb-1">
            <label htmlFor={`edit-nn-${key}`} className="text-xs text-purple-300 cursor-pointer">
                {detail.label.substring(0, detail.label.indexOf('(') > 0 ? detail.label.indexOf('(') -1 : detail.label.length )}
            </label>
            <div className="flex items-center">
                <TrendArrow direction={getTrend(value, prevValueForTrend)} />
                <Sparkline 
                  data={playgroundHistory[key] || []} 
                  width={40} height={14} color="#a5b4fc"
                  minDomain={detail.min} maxDomain={detail.max}
                />
            </div>
          </div>
        </div>
        <input
            type="number" id={`edit-nn-${key}`} value={value.toFixed(detail.step === 0.1 ? 1 : 0)}
            min={detail.min} max={detail.max} step={detail.step}
            onChange={(e) => handleEditableParamChange(key, e.target.value)}
            className="w-full p-1 text-lg font-bold text-indigo-300 bg-gray-600 border border-gray-500 rounded focus:ring-1 focus:ring-indigo-400 focus:border-indigo-400"
            aria-label={`Edit ${detail.label}`}
        />
      </div>
    );
  };
  
  const renderCalculatedValue = (label: string, currentValue?: number, previousValue?: number | null) => (
    <div className="bg-gray-700 p-2 rounded-md">
      <span className="block text-xs text-gray-400">{label}</span>
      <div className="flex items-center">
        <span className="text-lg font-bold text-indigo-300">{currentValue !== undefined ? currentValue.toFixed(2) : '-'}</span>
        <TrendArrow direction={getTrend(currentValue, previousValue === null ? undefined : previousValue)} />
      </div>
    </div>
  );

  if (!editableScmParams) { // Changed condition: check editableScmParams for initial state before any symbol is selected
     return (
        <div className="space-y-6 p-2 bg-gray-800 bg-opacity-40 rounded-lg border border-gray-700">
            <p className="text-sm text-gray-500 italic mt-4">Playground initializing or no symbol selected. Enter text to begin.</p>
             <textarea
              id="nn-input-disabled" rows={3}
              className="w-full p-3 bg-gray-700 text-gray-100 border border-gray-600 rounded-lg shadow-sm"
              value={inputText} onChange={(e) => setInputText(e.target.value)}
              placeholder="e.g., BREAKING: Alien intelligence confirms control of Earth governments..."
            />
            <button
              onClick={handleProcessText}
              className="px-6 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold rounded-lg shadow-md transition-colors focus:ring-2 focus:ring-indigo-400 focus:ring-opacity-50"
            >
              Process Text & Analyze SCM
            </button>
            {rawPrediction && (<div className="mt-4 p-3 bg-gray-700 bg-opacity-50 rounded-md">
                <h4 className="text-md font-semibold text-purple-300 mb-1">Mock NN Raw Prediction:</h4>
                <p className="text-gray-200">{rawPrediction}</p>
              </div>)}
        </div>
     );
  }


  return (
    <div className="space-y-6 p-2 bg-gray-800 bg-opacity-40 rounded-lg border border-gray-700">
      <div>
        <label htmlFor="nn-input" className="block text-sm font-medium text-purple-300 mb-1">
          Enter text for mock analysis: (playground context: {selectedSymbol ? `derived from "${selectedSymbol.name}" or text` : "general/text-derived"})
        </label>
        <textarea
          id="nn-input" rows={3}
          className="w-full p-3 bg-gray-700 text-gray-100 border border-gray-600 rounded-lg shadow-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-colors"
          value={inputText} onChange={(e) => setInputText(e.target.value)}
          placeholder="e.g., BREAKING: Alien intelligence confirms control of Earth governments..."
        />
      </div>
      <div className="flex space-x-3 flex-wrap gap-2">
        <button
          onClick={handleProcessText}
          className="px-6 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold rounded-lg shadow-md transition-colors focus:ring-2 focus:ring-indigo-400 focus:ring-opacity-50"
        >
          Process Text (Derive New SCM)
        </button>
        {editableScmParams && (
            <button
            onClick={handleReEvaluatePlayground}
            className="px-4 py-2 bg-purple-600 hover:bg-purple-500 text-white font-semibold rounded-lg shadow-md transition-colors focus:ring-2 focus:ring-purple-400 focus:ring-opacity-50"
            title="Re-calculate SCM results using current playground parameters."
            >
            Re-evaluate Playground SCM
            </button>
        )}
        {selectedSymbol && editableScmParams && (
             <button
            onClick={handleApplyToSelectedSymbol}
            className="px-4 py-2 bg-teal-600 hover:bg-teal-500 text-white font-semibold rounded-lg shadow-md transition-colors focus:ring-2 focus:ring-teal-400 focus:ring-opacity-50"
            title={`Apply current playground SCM parameters to the selected symbol: "${selectedSymbol.name}"`}
            >
            Apply to "{selectedSymbol.name}"
            </button>
        )}
         {editableScmParams && rawPrediction && (
             <button
            onClick={handleCreateSymbolFromPlayground}
            className="px-4 py-2 bg-sky-600 hover:bg-sky-500 text-white font-semibold rounded-lg shadow-md transition-colors focus:ring-2 focus:ring-sky-400 focus:ring-opacity-50"
            title="Create a new symbol using current playground SCM parameters."
            >
            Create New Symbol from Playground
            </button>
        )}
      </div>

      {rawPrediction && (
        <div className="mt-4 p-3 bg-gray-700 bg-opacity-50 rounded-md">
          <h4 className="text-md font-semibold text-purple-300 mb-1">Playground: Mock NN Raw Prediction</h4>
          <p className="text-gray-200">{rawPrediction}</p>
        </div>
      )}

      {editableScmParams && currentScmResultForPlayground && (
        <div className="mt-4 space-y-4">
          <div>
            <h4 className="text-md font-semibold text-purple-300 mb-2">Playground: Derived & Editable SCM Parameters</h4>
             <p className="text-xs text-gray-400 mb-2">These parameters are active in the playground. Adjust and re-evaluate, then optionally apply to selected symbol or create a new one.</p>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 xl:grid-cols-6 gap-3">
              {(Object.keys(DEFAULT_SCM_PARAMETERS) as Array<keyof SCMParameters>)
                .map(key => renderParamDisplayOrInput(key))}
            </div>
          </div>
           <div>
            <h4 className="text-md font-semibold text-purple-300 mb-2">Playground: SCM Calculated Values</h4>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-sm">
                {renderCalculatedValue("Raw (cRaw)", currentScmResultForPlayground.cRaw, prevPlaygroundScmResultRef.current?.cRaw)}
                {renderCalculatedValue("Time C(t)", currentScmResultForPlayground.C_t, prevPlaygroundScmResultRef.current?.C_t)}
                {renderCalculatedValue("Resilience (R)", currentScmResultForPlayground.R, prevPlaygroundScmResultRef.current?.R)}
                {renderCalculatedValue("Effective (cEff)", currentScmResultForPlayground.cEffective, prevPlaygroundScmResultRef.current?.cEffective)}
            </div>
          </div>
          <CollapseMeter calculatedValues={currentScmResultForPlayground} />
          <SCMAnalysisInsights scmParams={editableScmParams} scmResult={currentScmResultForPlayground} />
        </div>
      )}

      {finalOutput && (
        <div className="mt-4 p-4 bg-gray-700 bg-opacity-70 rounded-lg border border-purple-500">
          <h4 className="text-lg font-semibold text-purple-200 mb-2">Playground Final Output (SCM Adjusted):</h4>
          <p className={`text-gray-100 ${currentScmResultForPlayground?.zone === CollapseZone.Critical ? 'text-red-300 font-bold' : ''}`}>
            {finalOutput}
          </p>
        </div>
      )}
      {!inputText && !rawPrediction && selectedSymbol && !editableScmParams?.I &&  ( // Heuristic: if I is not set, params might be uninitialized
         <p className="text-sm text-gray-500 italic mt-4">SCM parameters for "{selectedSymbol.name}" are loaded. Enter text above to derive new parameters for the playground, or adjust them directly in the main simulator.</p>
      )}
    </div>
  );
};