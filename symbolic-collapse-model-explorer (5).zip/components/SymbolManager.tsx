import React, { useState } from 'react';
import { useSymbolStore } from '../store';
import { SymbolicNode } from '../types';

export const SymbolManager: React.FC = () => {
  const { symbols, selectedSymbolId, addSymbol, selectSymbol, deleteSymbol } = useSymbolStore(state => ({
    symbols: state.symbols,
    selectedSymbolId: state.selectedSymbolId,
    addSymbol: state.addSymbol,
    selectSymbol: state.selectSymbol,
    deleteSymbol: state.deleteSymbol,
  }));

  const [newSymbolName, setNewSymbolName] = useState('');

  const handleAddSymbol = () => {
    if (newSymbolName.trim()) {
      addSymbol(newSymbolName.trim());
      setNewSymbolName('');
    }
  };

  const handleDeleteSymbol = (id: string, event: React.MouseEvent) => {
    event.stopPropagation(); // Prevent selectSymbol from firing
    if (window.confirm(`Are you sure you want to delete symbol "${symbols.find(s=>s.id === id)?.name}"?`)) {
      deleteSymbol(id);
    }
  };

  return (
    <div className="p-4 bg-gray-800 bg-opacity-70 rounded-xl shadow-2xl backdrop-blur-md border border-gray-700 space-y-3">
      <h3 className="text-lg font-semibold text-purple-300">Symbol Ecosystem</h3>
      
      <div className="flex space-x-2">
        <input
          type="text"
          value={newSymbolName}
          onChange={(e) => setNewSymbolName(e.target.value)}
          placeholder="New symbol name (e.g., Liberty)"
          className="flex-grow p-2 bg-gray-700 text-gray-100 border border-gray-600 rounded-md shadow-sm focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500"
          onKeyPress={(e) => e.key === 'Enter' && handleAddSymbol()}
        />
        <button
          onClick={handleAddSymbol}
          disabled={!newSymbolName.trim()}
          className="px-4 py-2 bg-green-600 hover:bg-green-500 text-white font-semibold rounded-md shadow-md transition-colors disabled:bg-gray-500 disabled:cursor-not-allowed"
        >
          Add Symbol
        </button>
      </div>

      {symbols.length > 0 && (
        <div>
          <label htmlFor="symbol-select" className="block text-sm font-medium text-purple-300 mb-1">
            Active Symbol:
          </label>
          <select
            id="symbol-select"
            value={selectedSymbolId || ''}
            onChange={(e) => selectSymbol(e.target.value)}
            className="w-full p-2 bg-gray-700 text-gray-100 border border-gray-600 rounded-md shadow-sm focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500"
          >
            {symbols.map(symbol => (
              <option key={symbol.id} value={symbol.id}>
                {symbol.name} (Created: {new Date(symbol.createdAt).toLocaleTimeString()})
              </option>
            ))}
          </select>
        </div>
      )}
       {selectedSymbolId && symbols.find(s => s.id === selectedSymbolId) && (
         <button
          onClick={(e) => handleDeleteSymbol(selectedSymbolId, e)}
          className="px-4 py-2 text-sm bg-red-700 hover:bg-red-600 text-white font-semibold rounded-md shadow-md transition-colors w-full"
        >
          Delete "{symbols.find(s => s.id === selectedSymbolId)?.name}"
        </button>
       )}


      {symbols.length === 0 && <p className="text-sm text-gray-400">No symbols created yet. Add one to begin.</p>}
    </div>
  );
};
