
import React, { useState } from 'react';
import { SCMEvent } from '../types';
import { SCM_EVENTS } from '../constants'; // Ensure SCM_EVENTS is correctly imported/defined

interface EventInjectorProps {
  onEventTrigger: (event: SCMEvent) => void;
}

export const EventInjector: React.FC<EventInjectorProps> = ({ onEventTrigger }) => {
  const [selectedEventId, setSelectedEventId] = useState<string>(SCM_EVENTS.length > 0 ? SCM_EVENTS[0].id : '');

  const handleTrigger = () => {
    const eventToTrigger = SCM_EVENTS.find(e => e.id === selectedEventId);
    if (eventToTrigger) {
      onEventTrigger(eventToTrigger);
    }
  };

  const selectedEventDetails = SCM_EVENTS.find(e => e.id === selectedEventId);

  return (
    <div className="space-y-4 p-4 bg-gray-700 bg-opacity-50 rounded-lg border border-gray-600">
      <div>
        <label htmlFor="event-select" className="block text-sm font-medium text-purple-300 mb-1">
          Select a Global Event (will apply to current symbol):
        </label>
        <select
          id="event-select"
          value={selectedEventId}
          onChange={(e) => setSelectedEventId(e.target.value)}
          className="w-full p-2 bg-gray-600 text-gray-100 border border-gray-500 rounded-lg shadow-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-colors"
          disabled={SCM_EVENTS.length === 0}
        >
          {SCM_EVENTS.map(event => (
            <option key={event.id} value={event.id}>
              {event.name}
            </option>
          ))}
           {SCM_EVENTS.length === 0 && <option value="">No events available</option>}
        </select>
      </div>

      {selectedEventDetails && (
        <div className="text-xs text-gray-400 p-3 bg-gray-600 bg-opacity-30 rounded-md border border-gray-500">
          <p className="font-semibold text-purple-400">{selectedEventDetails.name}</p>
          <p>{selectedEventDetails.description}</p>
        </div>
      )}

      <button
        onClick={handleTrigger}
        disabled={!selectedEventId || !selectedEventDetails} // Ensure an event is actually selected
        className={`w-full px-6 py-3 rounded-lg font-semibold text-white transition-all duration-150 ease-in-out
          ${(!selectedEventId || !selectedEventDetails)
            ? 'bg-gray-500 cursor-not-allowed'
            : 'bg-red-600 hover:bg-red-500 focus:ring-2 focus:ring-red-400 focus:ring-opacity-50 shadow-lg hover:shadow-red-500/50'
          }`}
      >
        Trigger Event: {selectedEventDetails ? selectedEventDetails.name : "Select an Event"}
      </button>
      <p className="text-xs text-gray-500 mt-2">
        Note: Triggering an event will apply its effects to the currently selected symbol's SCM parameters. These changes are immediate and will interact with ongoing entropy and time progression for that symbol.
      </p>
    </div>
  );
};
