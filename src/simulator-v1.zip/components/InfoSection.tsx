
import React from 'react';

interface InfoSectionProps {
  title: string;
  children: React.ReactNode;
  badge?: string;
  badgeColor?: string; // e.g., "bg-blue-500"
}

export const InfoSection: React.FC<InfoSectionProps> = ({ title, children, badge, badgeColor = "bg-gray-500" }) => {
  return (
    <section className="p-6 bg-slate-800/50 rounded-xl shadow-xl border border-slate-700/50">
      <div className="flex items-center mb-4">
        <h2 className="text-2xl font-semibold text-sky-300">{title}</h2>
        {badge && (
          <span className={`ml-3 px-3 py-1 text-xs font-semibold text-white ${badgeColor} rounded-full`}>
            {badge}
          </span>
        )}
      </div>
      <div className="prose prose-sm sm:prose-base prose-invert max-w-none text-slate-300 prose-headings:text-sky-400 prose-strong:text-slate-100">
        {children}
      </div>
    </section>
  );
};
