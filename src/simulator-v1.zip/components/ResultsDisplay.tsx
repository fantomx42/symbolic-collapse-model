
import React from 'react';
import { CollapseZone } from '../types';

interface ResultsDisplayProps {
  collapsePressure: number;
  riskZone?: CollapseZone;
}

export const ResultsDisplay: React.FC<ResultsDisplayProps> = ({ collapsePressure, riskZone }) => {
  if (!riskZone) {
    return (
      <div className="mt-8 p-6 bg-slate-800 rounded-lg shadow-xl border border-slate-700 text-center">
        <p className="text-xl text-slate-400">Calculating results...</p>
      </div>
    );
  }

  return (
    <section aria-labelledby="results-heading" className="mt-10">
      <div className={`p-6 sm:p-8 rounded-xl shadow-2xl border-2 ${riskZone.borderColorClass} ${riskZone.colorClasses} transition-all duration-500`}>
        <h2 id="results-heading" className="text-2xl sm:text-3xl font-bold mb-2 text-center">Collapse Pressure Analysis</h2>
        <div className="text-center mb-6">
            <span className="text-5xl sm:text-7xl font-mono font-extrabold tracking-tight">
              {collapsePressure.toFixed(2)}
            </span>
            <span className="block text-sm uppercase tracking-wider mt-1">
              𝒞 Value
            </span>
        </div>
        
        <div className="text-center">
          <p className={`text-xl sm:text-2xl font-semibold mb-2`}>
            Risk Level: <span className="font-bold">{riskZone.risk}</span>
          </p>
          <p className="text-sm sm:text-base leading-relaxed">
            {riskZone.prose}
          </p>
        </div>
      </div>
    </section>
  );
};
