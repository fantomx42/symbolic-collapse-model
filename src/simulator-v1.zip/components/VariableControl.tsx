
import React from 'react';
import { ScmVariableInfo, ScmVariableId } from '../types';
import { getRubricDescriptionForScore } from '../constants';

interface VariableControlProps {
  variableInfo: ScmVariableInfo;
  currentValue: number;
  onValueChange: (value: number) => void;
  colorClass: string;
}

const colorMap: Record<string, { accent: string, track: string, thumb: string, text: string }> = {
    pink: { accent: 'border-pink-500', track: 'bg-pink-700/50', thumb: 'bg-pink-500', text: 'text-pink-400' },
    teal: { accent: 'border-teal-500', track: 'bg-teal-700/50', thumb: 'bg-teal-500', text: 'text-teal-400' },
    purple: { accent: 'border-purple-500', track: 'bg-purple-700/50', thumb: 'bg-purple-500', text: 'text-purple-400' },
    lime: { accent: 'border-lime-500', track: 'bg-lime-700/50', thumb: 'bg-lime-500', text: 'text-lime-400' },
    amber: { accent: 'border-amber-500', track: 'bg-amber-700/50', thumb: 'bg-amber-500', text: 'text-amber-400' },
};

export const VariableControl: React.FC<VariableControlProps> = ({ variableInfo, currentValue, onValueChange, colorClass }) => {
  const description = getRubricDescriptionForScore(variableInfo, currentValue);
  const colors = colorMap[colorClass] || colorMap.pink; // Default to pink if colorClass is invalid

  return (
    <div className={`p-4 rounded-lg bg-slate-800 shadow-lg border-l-4 ${colors.accent} transition-all duration-300 hover:shadow-xl`}>
      <div className="flex justify-between items-center mb-2">
        <label htmlFor={variableInfo.id} className={`block text-sm font-medium ${colors.text}`}>
          {variableInfo.symbol}: {variableInfo.fullName}
        </label>
        <span className={`text-lg font-semibold ${colors.text}`}>{currentValue}</span>
      </div>
      <input
        type="range"
        id={variableInfo.id}
        name={variableInfo.id}
        min="1"
        max="10"
        step="1"
        value={currentValue}
        onChange={(e) => onValueChange(parseInt(e.target.value, 10))}
        className={`w-full h-3 rounded-lg appearance-none cursor-pointer ${colors.track} [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:h-5 [&::-webkit-slider-thumb]:w-5 [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:${colors.thumb} [&::-moz-range-thumb]:h-5 [&::-moz-range-thumb]:w-5 [&::-moz-range-thumb]:rounded-full [&::-moz-range-thumb]:${colors.thumb} [&::-moz-range-thumb]:border-none`}
      />
      <p className="mt-3 text-xs text-slate-400 h-10 flex items-center">
        {description}
      </p>
    </div>
  );
};
