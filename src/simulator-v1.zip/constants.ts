
import { ScmVariableInfo, CollapseZone, InterventionTip, ScmVariableId } from './types';

export const SCM_VARIABLES_DATA: Record<ScmVariableId, ScmVariableInfo> = {
  I: {
    id: 'I',
    symbol: 'I',
    name: 'Info Load',
    fullName: 'Information Load',
    descriptors: [
      { min: 1, max: 2, description: "Very simple, low-volume signal" },
      { min: 3, max: 4, description: "Light content, minimal detail" },
      { min: 5, max: 6, description: "Moderate complexity" },
      { min: 7, max: 8, description: "Dense, cross-domain, fast-moving" },
      { min: 9, max: 10, description: "Overwhelming data, jargon, overload" },
    ]
  },
  S: {
    id: 'S',
    symbol: 'S',
    name: 'Abstraction',
    fullName: 'Symbolic Abstraction',
    descriptors: [
      { min: 1, max: 2, description: "Literal, sensory, grounded" },
      { min: 3, max: 4, description: "Slight generalization" },
      { min: 5, max: 6, description: "Balanced abstract + concrete" },
      { min: 7, max: 8, description: "Heavy use of theory/metaphor" },
      { min: 9, max: 10, description: "Recursive, ungrounded, ideology-laden" },
    ]
  },
  P: {
    id: 'P',
    symbol: 'P',
    name: 'Polarization',
    fullName: 'Polarization',
    descriptors: [
      { min: 1, max: 2, description: "Broad consensus, neutral" },
      { min: 3, max: 4, description: "Slight bias" },
      { min: 5, max: 6, description: "Depends on audience worldview" },
      { min: 7, max: 8, description: "Ideologically divisive" },
      { min: 9, max: 10, description: "Highly antagonistic, symbolic warfare" },
    ]
  },
  T: {
    id: 'T',
    symbol: 'T',
    name: 'Fidelity',
    fullName: 'Transmission Fidelity',
    descriptors: [
      { min: 1, max: 2, description: "Garbled, ambiguous, easily misread" },
      { min: 3, max: 4, description: "Unclear or confusing" },
      { min: 5, max: 6, description: "Interpretable with effort" },
      { min: 7, max: 8, description: "Clear and well-structured" },
      { min: 9, max: 10, description: "Extremely precise, resilient, repeatable meaning" },
    ]
  },
  E: {
    id: 'E',
    symbol: 'E',
    name: 'Coherence',
    fullName: 'Epistemic Coherence',
    descriptors: [
      { min: 1, max: 2, description: "Contradictory, incoherent, false" },
      { min: 3, max: 4, description: "Spotty logic, cherry-picked data" },
      { min: 5, max: 6, description: "Mostly coherent with gaps" },
      { min: 7, max: 8, description: "Structured logic and internally consistent" },
      { min: 9, max: 10, description: "Rigorous, falsifiable, deeply coherent knowledge system" },
    ]
  }
};

export const INITIAL_SCM_VALUES: Record<ScmVariableId, number> = {
  I: 5,
  S: 5,
  P: 5,
  T: 5,
  E: 5,
};

export const COLLAPSE_ZONES: CollapseZone[] = [
  { 
    minC: 0, maxC: 3, risk: "Stable", 
    prose: "The system is currently stable and resilient. Symbolic integrity is maintained.",
    colorClasses: "bg-green-600/20 text-green-300", 
    borderColorClass: "border-green-500" 
  },
  { 
    minC: 3, maxC: 7, risk: "Symbolic Stress", 
    prose: "The system is under stress. Early signs of symbolic misalignments may be present.",
    colorClasses: "bg-yellow-600/20 text-yellow-300", 
    borderColorClass: "border-yellow-500" 
  },
  { 
    minC: 7, maxC: 10, risk: "Narrative Fracture", 
    prose: "Significant fractures in shared meaning are likely. Communication breakdown is probable.",
    colorClasses: "bg-orange-600/20 text-orange-300", 
    borderColorClass: "border-orange-500" 
  },
  { 
    minC: 10, maxC: null, risk: "Collapse Zone", 
    prose: "The system is in or approaching a state of symbolic collapse. Meaning is critically compromised.",
    colorClasses: "bg-red-600/20 text-red-300", 
    borderColorClass: "border-red-500" 
  },
];

export const INTERVENTION_TIPS: InterventionTip[] = [
  { variable: 'I', signal: "Overload, firehose of content", fix: "Summarize, filter, chunk, slow input" },
  { variable: 'S', signal: "Detached, vague, ideology-saturated", fix: "Reground in real examples, reduce metaphor, clarify terms" },
  { variable: 'P', signal: "Interpretive fracture", fix: "Neutral framing, viewpoint diversity, empathy modeling" },
  { variable: 'T', signal: "Ambiguity, miscommunication", fix: "Repeat, simplify, define terms, structure clearly" },
  { variable: 'E', signal: "Contradiction, confusion", fix: "Add sourcing, fact-checking, logical scaffolding" },
];

export const getRubricDescriptionForScore = (variableInfo: ScmVariableInfo, score: number): string => {
  const descriptor = variableInfo.descriptors.find(d => score >= d.min && score <= d.max);
  return descriptor ? descriptor.description : "Invalid score.";
};
