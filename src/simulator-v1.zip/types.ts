
export type ScmVariableId = 'I' | 'S' | 'P' | 'T' | 'E';

export interface ScoreDescriptor {
  min: number;
  max: number;
  description: string;
}

export interface ScmVariableInfo {
  id: ScmVariableId;
  name: string; // Short name (e.g., "Info Load")
  fullName: string; // Full name (e.g., "Information Load")
  symbol: string; // The letter symbol (I, S, P, T, E)
  descriptors: ScoreDescriptor[];
}

export interface ScmValues {
  I: number;
  S: number;
  P: number;
  T: number;
  E: number;
}

export interface CollapseZone {
  minC: number;
  maxC: number | null; // null for "10+" or similar open-ended upper bound
  risk: string;
  prose: string;
  colorClasses: string; // Tailwind classes for background and text color
  borderColorClass: string;
}

export interface InterventionTip {
  variable: ScmVariableId;
  signal: string;
  fix: string;
}
