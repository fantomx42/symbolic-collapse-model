
import React from 'react';
import { ScmSimulatorPage } from './pages/ScmSimulatorPage';

const App: React.FC = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-gray-900 text-slate-200 flex flex-col items-center p-4 sm:p-6 md:p-8">
      <header className="w-full max-w-5xl mb-8 text-center">
        <h1 className="text-4xl sm:text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-sky-400 to-blue-500 py-2">
          Symbolic Collapse Model <span className="text-indigo-400">Simulator</span>
        </h1>
        <p className="text-slate-400 mt-2 text-sm sm:text-base">
          Explore what happens when meaning breaks down—across minds, machines, messages, and civilizations.
        </p>
      </header>
      <main className="w-full max-w-5xl">
        <ScmSimulatorPage />
      </main>
      <footer className="w-full max-w-5xl mt-12 text-center text-slate-500 text-xs">
        <p>Symbolic Collapse Model conceptualized by an external source. Simulator by AI.</p>
      </footer>
    </div>
  );
};

export default App;
