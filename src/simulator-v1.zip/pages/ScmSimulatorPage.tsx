
import React, { useState, useMemo, useCallback } from 'react';
import { ScmValues, ScmVariableId, CollapseZone, InterventionTip } from '../types';
import { SCM_VARIABLES_DATA, INITIAL_SCM_VALUES, COLLAPSE_ZONES, INTERVENTION_TIPS, getRubricDescriptionForScore } from '../constants';
import { VariableControl } from '../components/VariableControl';
import { ResultsDisplay } from '../components/ResultsDisplay';
import { InfoSection } from '../components/InfoSection';

const EquationDisplay: React.FC = () => (
  <div className="text-center my-6 p-4 bg-slate-800 rounded-lg shadow-md">
    <p className="text-xl sm:text-2xl font-mono text-sky-300">
      <span className="italic font-semibold">C</span> = (
      <span className="text-pink-400">I</span> × <span className="text-teal-400">S</span> × <span className="text-purple-400">P</span>
      ) / (<span className="text-lime-400">T</span> × <span className="text-amber-400">E</span>)
    </p>
  </div>
);

export const ScmSimulatorPage: React.FC = () => {
  const [scmValues, setScmValues] = useState<ScmValues>(INITIAL_SCM_VALUES);

  const handleValueChange = useCallback((id: ScmVariableId, value: number) => {
    setScmValues(prev => ({ ...prev, [id]: value }));
  }, []);

  const collapsePressure = useMemo(() => {
    const { I, S, P, T, E } = scmValues;
    if (T === 0 || E === 0) return Infinity; // Should not happen with 1-10 scale
    return (I * S * P) / (T * E);
  }, [scmValues]);

  const currentRiskZone = useMemo((): CollapseZone | undefined => {
    return COLLAPSE_ZONES.find(zone => 
      collapsePressure >= zone.minC && (zone.maxC === null || collapsePressure < zone.maxC)
    ) || COLLAPSE_ZONES[COLLAPSE_ZONES.length -1]; // Default to last zone if somehow out of bounds
  }, [collapsePressure]);

  return (
    <div className="space-y-12">
      <InfoSection title="Overview" badge="Model Core" badgeColor="bg-sky-500">
        <p>The Symbolic Collapse Model (SCM) is a diagnostic tool designed to detect when symbolic systems—language, knowledge, institutions, cognition, or AI—begin to fail. At its core is a simple but powerful equation to measure pressure on a system’s symbolic integrity.</p>
      </InfoSection>

      <section className="bg-slate-800/50 p-6 rounded-xl shadow-2xl border border-slate-700">
        <h2 className="text-3xl font-semibold mb-6 text-center text-transparent bg-clip-text bg-gradient-to-r from-lime-400 to-emerald-500">SCM Calculator</h2>
        <EquationDisplay />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-6">
          {(Object.keys(SCM_VARIABLES_DATA) as ScmVariableId[]).map(id => (
            <VariableControl
              key={id}
              variableInfo={SCM_VARIABLES_DATA[id]}
              currentValue={scmValues[id]}
              onValueChange={(value) => handleValueChange(id, value)}
              colorClass={
                id === 'I' ? 'pink' : 
                id === 'S' ? 'teal' : 
                id === 'P' ? 'purple' : 
                id === 'T' ? 'lime' : 'amber'
              }
            />
          ))}
        </div>
      </section>

      <ResultsDisplay collapsePressure={collapsePressure} riskZone={currentRiskZone} />

      <InfoSection title="From Measurement to Action" badge="Interventions" badgeColor="bg-indigo-500">
        <p className="mb-4">SCM isn’t just a warning system. It’s a tool for diagnosing and repairing symbolic breakdowns. Once you calculate 𝒞 using the rubric, you can identify which variable(s) are driving collapse pressure—and apply targeted interventions.</p>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-slate-700 bg-slate-800/70 rounded-lg shadow">
            <thead className="bg-slate-700/50">
              <tr>
                <th className="px-4 py-3 text-left text-xs font-medium text-sky-300 uppercase tracking-wider">Variable</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-sky-300 uppercase tracking-wider">What It Signals</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-sky-300 uppercase tracking-wider">What You Can Fix</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-700">
              {INTERVENTION_TIPS.map((tip) => (
                <tr key={tip.variable} className="hover:bg-slate-700/30 transition-colors duration-150">
                  <td className="px-4 py-3 whitespace-nowrap text-sm font-medium text-slate-300">{SCM_VARIABLES_DATA[tip.variable].symbol}: {SCM_VARIABLES_DATA[tip.variable].name}</td>
                  <td className="px-4 py-3 text-sm text-slate-400">{tip.signal}</td>
                  <td className="px-4 py-3 text-sm text-slate-400">{tip.fix}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p className="mt-4 text-sm text-slate-500">Example: If 𝒞 is high and E is low → improve coherence (add evidence, clarify logic). If I is high and T is low → slow the info flow and add structure. Recalculate after intervention. If 𝒞 drops, your system is stabilizing.</p>
      </InfoSection>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <InfoSection title="Why This Exists" badge="Context" badgeColor="bg-rose-500">
          <p>We live in a world of symbolic stress: AI models hallucinate under meaning strain. Institutions fracture not from lack of power—but from loss of coherence. Social discourse splinters when symbols no longer mean the same thing to everyone. SCM provides a way to measure that pressure—before collapse becomes irreversible.</p>
        </InfoSection>

        <InfoSection title="Origins: Shannon, Gödel, and You" badge="Inspiration" badgeColor="bg-cyan-500">
          <p>This model stands at the intersection of: Claude Shannon’s Information Theory (measuring signal, noise, and overload), Kurt Gödel’s Incompleteness Theorem (recognizing systems can’t always resolve their own failure), and You (the human or AI trying to sense fracture).</p>
        </InfoSection>
      </div>

      <InfoSection title="Potential Applications and Extensions" badge="Future Scope" badgeColor="bg-violet-500">
        <ul className="list-disc list-inside space-y-2 text-slate-400">
          <li><strong>AI Alignment & Monitoring:</strong> Integrate SCM into language models to detect abstraction overload, hallucination, or epistemic drift.</li>
          <li><strong>Epistemic Health Dashboards:</strong> Score media, institutions, or discourse threads for real-time collapse pressure.</li>
          <li><strong>Narrative Fragility Analysis:</strong> Track symbolic fracture across time in political, cultural, or ideological narratives.</li>
          <li><strong>SCP-GATE (Hardware Module):</strong> A future version could run the formula in real-time, at the transistor or inference layer, as an epistemic failsafe.</li>
          <li><strong>Educational & Diagnostic Use:</strong> Teach systems thinking, communication breakdown, and media literacy.</li>
          <li><strong>Historical Retrospectives:</strong> Apply SCM to known collapse events for pattern discovery.</li>
          <li><strong>Multi-Agent Systems & Governance:</strong> Use SCM as a symbolic resilience indicator in distributed decision-making.</li>
        </ul>
        <p className="mt-4 text-sm text-slate-500">This model is not a product. It’s a lens—a way to interrogate what’s breaking, see it coming, and build systems that hold together longer.</p>
      </InfoSection>
    </div>
  );
};
